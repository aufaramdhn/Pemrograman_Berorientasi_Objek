package pertemuan4;

public class persistence {
    public void save(lingkaran obj){
        System.out.println("Saving object: " + obj);
    }
}
