package pertemuan4;

public class mahasiswa {
    private String NRP;

    public String getNRP(){
        return NRP;
    }

    public void setNRP(String NRP){
        this.NRP = NRP;
    }
}
